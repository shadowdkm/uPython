import ble_uart_peripheral
import machine

ble_uart_peripheral.demo()
machine.reset()
