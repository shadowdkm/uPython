

from machine import Pin, SPI
import machine, sdcard, os
# construct an SPI bus on the given pins
# polarity is the idle state of SCK
# phase=0 means sample on the first edge of SCK, phase=1 means the second
spi = SPI(-1, phase=0, sck=Pin(21), mosi=Pin(23), miso=Pin(22))

sd = sdcard.SDCard(spi, machine.Pin(5))
print("Sd working")
os.mount(sd,"/SDCard")



